(function() {
  $('.carousel').carousel({
    interval: false
  });

}).call(this);
