(function() {
  $(function() {
    return $('.error').removeClass('error', 2000);
  });

}).call(this);
